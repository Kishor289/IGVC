import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class CircularMotion(Node):
    def __init__(self):
        super().__init__('circular_motion')
        self.publisher_ = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)

    def move_in_circle(self, radius, speed):
        twist = Twist()
        twist.linear.x = speed
        twist.angular.z = speed / radius  # ω = v / r

        self.get_logger().info(f"Moving in a circle with radius {radius} and speed {speed}")
        
        while rclpy.ok():
            self.publisher_.publish(twist)
            rclpy.spin_once(self, timeout_sec=0.1)

def main():
    rclpy.init()
    node = CircularMotion()
    
    radius = float(input("Enter the radius of the circle: "))
    speed = float(input("Enter the speed of the turtle: "))

    node.move_in_circle(radius, speed)

    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
