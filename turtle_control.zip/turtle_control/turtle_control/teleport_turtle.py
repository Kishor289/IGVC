import rclpy
from rclpy.node import Node
from turtlesim.srv import TeleportAbsolute

class TeleportTurtle(Node):
    def __init__(self):
        super().__init__('teleport_turtle')
        self.cli = self.create_client(TeleportAbsolute, '/turtle1/teleport_absolute')
        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for teleport service...')

    def teleport(self, x, y, theta):
        req = TeleportAbsolute.Request()
        req.x = x
        req.y = y
        req.theta = theta

        future = self.cli.call_async(req)
        rclpy.spin_until_future_complete(self, future)
        if future.result() is not None:
            self.get_logger().info(f"Turtle teleported to ({x}, {y}, {theta})")
        else:
            self.get_logger().error("Failed to teleport the turtle")

def main():
    rclpy.init()
    node = TeleportTurtle()
    
    x = float(input("Enter X coordinate: "))
    y = float(input("Enter Y coordinate: "))
    theta = float(input("Enter orientation (θ in radians): "))

    node.teleport(x, y, theta)

    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
