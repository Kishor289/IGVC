# TurtleSim Motion Control (IGVC Assignment)

## **Overview**
This package implements two ROS2 nodes:
1. **Teleport Node** (`teleport_turtle.py`): Moves the turtle instantly to a specified location.
2. **Circular Motion Node** (`circular_motion.py`): Moves the turtle in a circular trajectory.

## **Installation & Setup**
1. Clone the repository (or create the package manually).
2. Build the package:
   ```bash
   cd ~/ros2_ws
   colcon build
   source install/setup.bash
