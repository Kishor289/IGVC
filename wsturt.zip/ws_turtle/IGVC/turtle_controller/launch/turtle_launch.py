import launch
import launch_ros.actions

def generate_launch_description():
    return launch.LaunchDescription([
        launch_ros.actions.Node(
            package='turtle_controller',
            executable='circular_motion',
            name='circular_motion',
            output='screen'
        ),
        launch_ros.actions.Node(
            package='turtle_controller',
            executable='teleport_turtle',
            name='teleport_turtle',
            output='screen'
        )
    ])

