
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import sys
import math

class CircularMotion(Node):
    def __init__(self, radius, speed):
        super().__init__('circular_motion')
        
        # Store parameters
        self.radius = float(radius)
        self.speed = float(speed)
        
        # Calculate angular velocity based on v = r*ω, so ω = v/r
        self.angular_velocity = self.speed / self.radius
        
        # Create publisher
        self.publisher = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)
        
        # Set up timer to publish velocity commands
        self.timer = self.create_timer(0.1, self.publish_velocity)
        
        self.get_logger().info(f'Moving turtle in circle with radius={radius}, speed={speed}')
        self.get_logger().info(f'Linear velocity={speed}, angular velocity={self.angular_velocity}')
        
    def publish_velocity(self):
        # Create message
        msg = Twist()
        
        # Set linear velocity (forward speed)
        msg.linear.x = self.speed
        
        # Set angular velocity (turning speed)
        msg.angular.z = self.angular_velocity
        
        # Publish the message
        self.publisher.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    
    if len(sys.argv) == 3:
        try:
            radius = float(sys.argv[1])
            speed = float(sys.argv[2])
            
            if radius <= 0 or speed <= 0:
                raise ValueError("Radius and speed must be positive")
                
            node = CircularMotion(radius, speed)
            rclpy.spin(node)
            node.destroy_node()
            
        except ValueError as e:
            print(f"Error: {e}")
            print('Usage: ros2 run turtle_controller circular_motion <radius> <speed>')
    else:
        print('Usage: ros2 run turtle_controller circular_motion <radius> <speed>')
    
    rclpy.shutdown()

if __name__ == '__main__':
    main()
