#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from turtlesim.srv import TeleportAbsolute
import sys

class TurtleTeleporter(Node):
    def __init__(self):
        super().__init__('turtle_teleporter')
        self.client = self.create_client(TeleportAbsolute, '/turtle1/teleport_absolute')
        while not self.client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for teleport service...')
    
    def teleport_turtle(self, x, y, theta):
        request = TeleportAbsolute.Request()
        request.x = float(x)
        request.y = float(y)
        request.theta = float(theta)
        
        future = self.client.call_async(request)
        rclpy.spin_until_future_complete(self, future)
        
        if future.result() is not None:
            self.get_logger().info(f'Successfully teleported turtle to x={x}, y={y}, theta={theta}')
        else:
            self.get_logger().error('Failed to teleport turtle')

def main(args=None):
    rclpy.init(args=args)
    teleporter = TurtleTeleporter()
    
    if len(sys.argv) == 4:
        try:
            x = float(sys.argv[1])
            y = float(sys.argv[2])
            theta = float(sys.argv[3])
            teleporter.teleport_turtle(x, y, theta)
        except ValueError:
            print('Invalid values. Please enter numeric values for x, y, and theta.')
    else:
        # Interactive mode
        try:
            print("\n--- Turtle Teleportation ---")
            x = float(input("Enter X coordinate (0-11): "))
            y = float(input("Enter Y coordinate (0-11): "))
            theta = float(input("Enter orientation theta (radians): "))
            
            teleporter.teleport_turtle(x, y, theta)
        except ValueError:
            print('Invalid input. Please enter numeric values.')
    
    teleporter.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
